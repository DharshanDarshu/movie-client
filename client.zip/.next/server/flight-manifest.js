self.__RSC_MANIFEST={
  "__ssr_module_mapping__": {
    "(app-client)/./node_modules/next/dist/client/image.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "",
        "chunks": [
          "app/add-language/page:app/add-language/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "*",
        "chunks": [
          "app/add-language/page:app/add-language/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "default",
        "chunks": [
          "app/add-language/page:app/add-language/page"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/link.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "*",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "default",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./components/MovieForm.tsx": {
      "": {
        "id": "(sc_client)/./components/MovieForm.tsx",
        "name": "",
        "chunks": [
          "app/add-movie/page:app/add-movie/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/MovieForm.tsx",
        "name": "*",
        "chunks": [
          "app/add-movie/page:app/add-movie/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/MovieForm.tsx",
        "name": "default",
        "chunks": [
          "app/add-movie/page:app/add-movie/page"
        ],
        "async": false
      }
    },
    "(app-client)/./components/LanguageForm.tsx": {
      "": {
        "id": "(sc_client)/./components/LanguageForm.tsx",
        "name": "",
        "chunks": [
          "app/add-language/page:app/add-language/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/LanguageForm.tsx",
        "name": "*",
        "chunks": [
          "app/add-language/page:app/add-language/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/LanguageForm.tsx",
        "name": "default",
        "chunks": [
          "app/add-language/page:app/add-language/page"
        ],
        "async": false
      }
    }
  },
  "__edge_ssr_module_mapping__": {},
  "__entry_css_files__": {
    "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\app\\layout": [
      "static/css/_app-client_styles_globals_css.css"
    ]
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\node_modules\\next\\dist\\client\\image.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "",
      "chunks": [
        "app/add-language/page:app/add-language/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "*",
      "chunks": [
        "app/add-language/page:app/add-language/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "default",
      "chunks": [
        "app/add-language/page:app/add-language/page"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\node_modules\\next\\dist\\client\\link.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "*",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "default",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\node_modules\\next\\dist\\client\\components\\app-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\components\\MovieForm.tsx": {
    "": {
      "id": "(app-client)/./components/MovieForm.tsx",
      "name": "",
      "chunks": [
        "app/add-movie/page:app/add-movie/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/MovieForm.tsx",
      "name": "*",
      "chunks": [
        "app/add-movie/page:app/add-movie/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/MovieForm.tsx",
      "name": "default",
      "chunks": [
        "app/add-movie/page:app/add-movie/page"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\components\\LanguageForm.tsx": {
    "": {
      "id": "(app-client)/./components/LanguageForm.tsx",
      "name": "",
      "chunks": [
        "app/add-language/page:app/add-language/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/LanguageForm.tsx",
      "name": "*",
      "chunks": [
        "app/add-language/page:app/add-language/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/LanguageForm.tsx",
      "name": "default",
      "chunks": [
        "app/add-language/page:app/add-language/page"
      ],
      "async": false
    }
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\styles\\globals.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/_app-client_styles_globals_css.css"
      ]
    }
  }
}