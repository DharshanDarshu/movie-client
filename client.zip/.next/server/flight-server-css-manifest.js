self.__RSC_CSS_MANIFEST={
  "__entry_css_mods__": {
    "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\app\\page": [
      "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\styles\\globals.css"
    ],
    "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\app\\add-movie\\page": [
      "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\styles\\globals.css"
    ]
  },
  "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\app\\layout.tsx": [
    "D:\\Darshan\\After Traning\\Projects\\Video Stream\\client\\styles\\globals.css"
  ]
}